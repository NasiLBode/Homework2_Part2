﻿// Homework No. 2 Exerciase No. 2
// File Name: Homework2_Part2.cs
// @author: Nasi Bode
// Date: 01 September 2023
//
// Problem Statement: Write a program that converts degrees
// Fahrenheit to Celsius using the following formula.
// degreesC= 5(degreesF - 32)/9
// Prompt the user to enter a temperature in degrees Fahrenheit
// let the program print out the equivalent Celsius temperature,
// including the fractional part to one decimal point.
// Use the Math.Round(number, decimal) method.
//
// Overall Plan:
// 1. Print welcoming message to the screen
// 2. Get fahrenheit degrees from user
// 3. Convert the string to double data type value
// 4. Use given formula to convert degreesF to celsius
// 5. Use the Math.Round(number, decimal) method to round the numbers to 1 digit
// 6. Print result to screen



//import necessary classes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_Part2
{
    class Program
    {
        public static void Main(string[] args)
        {
            //print welcoming message to the screen
            Console.WriteLine("Hello! This program will convert degrees Fahrenheit to Celsius!");
            Console.WriteLine("Please enter a temper in degrees Fahrenheit: ");

            //gather input from the user
            string input = Console.ReadLine();

            //convert input to usable numbers
            double degreesF = Convert.ToDouble(input);

            //convert fahrenheit to celsius using provided equation
            double degreesC = ((5 * (degreesF - 32)) / 9);

            //round the number to two digits
            //print the result to the screen
            Console.WriteLine(Math.Round(degreesF, 1) + " degrees Fahrenheit = " + Math.Round(degreesC, 1) + " degrees Celsius");

        }
    }
}